/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.edu.itoaxaca.citas.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;
import mx.edu.itoaxaca.citas.modelo.Paciente;

/**
 *
 * @author omar
 */
@WebServlet(name = "AltaPaciente", urlPatterns = {"/AltaPaciente"})
public class AltaPaciente extends HttpServlet {
    
    private EntityManagerFactory emf;
    
    private UserTransaction utx;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String nombrep=request.getParameter("nombrePaciente");
            SimpleDateFormat formatoF=new SimpleDateFormat("dd/MM/yy");
            String fechat=request.getParameter("fecha");
            Date fechan=new Date();
            try{
                fechan= formatoF.parse(fechat);
            }catch(Exception e){}
            Integer estatura=Integer.parseInt(request.getParameter("estatura"));
            String sexo=request.getParameter("sexo");
            
            Paciente p=new Paciente();
            p.setNombre(nombrep);
            p.setEstatura(estatura);
            p.setFechanac(fechan);
            p.setSexo(sexo.charAt(0));
            
            
            
            emf=Persistence.createEntityManagerFactory("citasPacientesPU");
            PacientesJpaController control =new PacientesJpaController(utx,emf);
            
            
            emf=Persistence.createEntityManagerFactory("citasPacientesPU");//dato copiado de configurationFiles/persistence.xml
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AltaPaciente</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AltaPaciente at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("Nombre: "+nombrep);
            out.println("Fecha: " +fechat);
            out.println("Sexo: "+sexo);
            out.println("Estatura: "+estatura);
            
            out.println("</html>");
            
            
            try{
            control.create(p);
            response.sendRedirect("index.html");
            }catch(Exception e){
                System.out.println("Error al insertar");
            }finally{
            out.close();
        }
            

        }            
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
