/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usocomponentetexto;

/**
 *
 * @author omar
 */
public class UsoComponenteTexto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        usoComponente u= new usoComponente();
        u.setVisible(true);

    }
    
}
